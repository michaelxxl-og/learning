from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Mike",
	author_email="michaelqp26@gmail.com",
	url="wwww.gei.com",
	packages=["calculos","calculos.redondeo_potencia"]

	)